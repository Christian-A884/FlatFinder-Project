import { createContext } from "react";
import { Flat } from "../interface";

export const FlatContext = createContext([] as Flat[])


const ProfileUpdate = () => {
  return (
    <div>ProfileUpdate</div>
  )
}

export default ProfileUpdate